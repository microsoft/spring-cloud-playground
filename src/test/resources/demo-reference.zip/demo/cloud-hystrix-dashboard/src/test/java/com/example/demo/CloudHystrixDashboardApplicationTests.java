package com.example.demo;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.junit.Ignore;

@RunWith(SpringRunner.class)
@SpringBootTest
@Ignore
public class CloudHystrixDashboardApplicationTests {

	@Test
	public void contextLoads() {
	}

}
